package org.foi.uzdiz.mmusica.enums;

public enum TypeOfService {
    H,
    S,
    P,
    R
}
