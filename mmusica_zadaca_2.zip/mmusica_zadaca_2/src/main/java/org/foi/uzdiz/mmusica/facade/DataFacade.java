package org.foi.uzdiz.mmusica.facade;

public interface DataFacade {
    void initializeDataWithCommand(String command);
}
