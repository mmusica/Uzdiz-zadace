package org.foi.uzdiz.mmusica.model.state;

public interface VehicleContext {
    void changeState(VehicleState vehicleState);
}
