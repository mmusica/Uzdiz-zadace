package org.foi.uzdiz.mmusica.enums;

public enum TypeOfPackage {
    A,
    B,
    C,
    D,
    E,
    X
}

