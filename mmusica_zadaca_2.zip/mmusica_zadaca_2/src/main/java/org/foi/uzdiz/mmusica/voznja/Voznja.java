package org.foi.uzdiz.mmusica.voznja;

import java.util.List;

public class Voznja {
    List<Segment> segmentList;
}
