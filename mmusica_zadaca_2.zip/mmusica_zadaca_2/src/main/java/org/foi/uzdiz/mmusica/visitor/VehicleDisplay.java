package org.foi.uzdiz.mmusica.visitor;

public interface VehicleDisplay {
    void accept(DataDisplayVisitor dataDisplayVisitor);
}
