package org.foi.uzdiz.mmusica.enums;

public enum UserCommands {
    IP,
    VR,
    Q
}
