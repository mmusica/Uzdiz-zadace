package org.foi.uzdiz.mmusica.observer;

public interface Observer {
    void update(Subject subject);
    String getName();

}
